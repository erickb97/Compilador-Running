
package com.gt.Running;
import java.io.IOException;
import java.util.Scanner;

import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CommonTokenStream;

public class Main {

	private static final String EXTENSION = "rn";

	public static void main(String[] args) throws IOException {
		String program = args.length > 1 ? args[1] : "test/test." + EXTENSION;

		System.out.println("Interpreting file " + program);

		rnLexer lexer = new rnLexer(new ANTLRFileStream(program));
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		rnParser parser = new rnParser(tokens);

		rnParser.StartContext tree = parser.start();

		rnCustomVisitor visitor = new rnCustomVisitor();
		visitor.visit(tree);

		System.out.println("Interpretation finished");
		
		
	 System.out.println("Interpretando Java");
		  
	 System.out.println("--------------------------------------------------------------");
	 
	 
		System.out.println("Tokens Registrados");
		System.out.println("tokens detectados:   "+tokens.getTokens());
		
		System.out.println("**------------------------------------------------------------------------------------**" );
		System.out.println("**------------------------------------------------------------------------------------** \n\n" );
		
		
		Scanner s = new Scanner(System.in);
		System.out.println("\n");
		
		String insert = "";
		String in ="";
		

		
		System.out.print(insert);
			
			
		//	do{
				insert = s.nextLine();
				Validaciones.anLexico(insert);
				
			//}while(insert != "-1");
			

			in = s.nextLine();
			
			Validaciones.anSint(in);  

	}

}
