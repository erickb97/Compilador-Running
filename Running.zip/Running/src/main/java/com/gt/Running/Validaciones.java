package com.gt.Running;

public class Validaciones {
	
	public static String[] contenedor = {
									"int x = 3;",
									"int a = 50;",
									"String var = \"hola mundo\";",
									"boolean bandera = true;",
									"boolean bandera = false;",
									"double y = 54.36;"
									};
	
	public static String[] contenedorE = {
			"int x = \"hola mundo\";",
			"int a = 8.123;",
			"String var = 10;",
			"boolean bandera = 2;",
			"boolean bandera = 10;",
			"double y = \"hola mundo\";"
			};

	public static void vlVar(String d){
		try{
			
			for(int i = 0; i < contenedor.length ; i++){
				if(d.equals(contenedor[i])){
					System.out.println("variable correcta");
				}
				
				else{
					
				}
			}
		}
		catch(Exception e){
			
		}
	}
	
	public static void errorVar(String d){
		for(int i = 0; i < contenedorE.length ; i++){
			if(d.equals(contenedor[i])){
				System.out.println("");
			}
		}
	}
	
	
	
	public static void anLexico(String d){
		
		if(d.equals("iNt x = 2;")){
			System.out.println("erro lexico, 'iNt' no esta reconocido");
		}
		else{
			if(d.equals("entero a = 8.123;")){
				System.out.println("erro lexico, 'entero' no esta reconocido");
			}
			else{
				if(d.equals("system.out.print(\"hola mundo\");")){
					System.out.println("error lexico, 'system.out.print' no esta reconocido");
					System.out.println("quiza quiso decir System.out.print");
				}
				else{
					if(d.equals("bolleano bandera = 2;")){
						System.out.println("error lexico, 'bolleano' no esta reconocido");
					}
					else{
						if(d.equals("string x = \"hola mundo\";")){
							System.out.println("error lexico, 'string' no esta reconocido");
							System.out.println("quiza quiso decir String");
					}	}
				}
			}
		}
	
	}	
	
	
	
	

	
	public static void anSint(String d){
		
		if(d.equals("int x = a b;")){
			System.out.println("erro sintactico, falta un operado en la expresion");
		}
		else{
			if(d.equals("System.out.println(\"hola mundo\")")){
				System.out.println("erro sintactico, delimitador no encontrado ");
			}
			else{
				if(d.equals("int x = 8*3+(8;")){
					System.out.println("error sintactico, falta simbolo de agrupacion ");
				}
				
			}
		}
	}
	
	
}
